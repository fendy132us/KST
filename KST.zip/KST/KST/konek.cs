﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KST
{
    class konek
    {
        public string koneksi = "Integrated Security=true;Initial Catalog=KST;Data Source=DESKTOP-9U797PB\\SQLEXPRESS";

    }
}
