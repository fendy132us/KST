﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;


namespace KST
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            openFileDialog1.ShowDialog();
            textBox1.Text = openFileDialog1.FileName.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
                        
            string tampung = "";
            string name = ""; string tamp_name1 = ""; string tamp_name2 = ""; string tamp_name3 = "";
            char tamp2 ;
            string[] lines = System.IO.File.ReadAllLines(textBox1.Text);
            int hit = 0;

            string sql ="" ;
            SqlConnection con = new SqlConnection();
            konek kelas1 = new konek();
            con.ConnectionString = kelas1.koneksi;


            for (int i = 0; i <= lines.Length - 1; i++)
            {

                tampung = lines[i];
                char[] tamp = tampung.ToArray();

                for (int j = i; j <= tamp.Length; j++)
                {
                    tamp2 = tamp[j];

                    if (tamp2.Equals(" "))
                    {
                        hit = hit + 1;
                        if (hit == 1)
                        {
                            tamp[j] = tamp[j + 1];
                            tamp2 = tamp[j];
                            name = name + Char.ToString(tamp2);
                            tamp_name2 = name;
                        }
                        else if (hit == 2)
                        {
                            tamp[j] = tamp[j + 1];
                            tamp2 = tamp[j];
                            name = name + Char.ToString(tamp2);
                            tamp_name3 = name;
                        }

                    }
                    else
                    {
                        name = name + Char.ToString(tamp2);
                        tamp2 = tamp[j];
                        name = name + Char.ToString(tamp2);
                        tamp_name1 = name;
                    }

                }
                
                 //insert

                if (hit == 1)
                {
                    sql = "insert into Table_1(name1,name2,name3) values('" + tamp_name1 + "','','"+ tamp_name2 +"')";
                }
                else if (hit == 2)
                {
                    sql = "insert into Table_1(name1,name2,name3) values('" + tamp_name1 + "','" + tamp_name2 + "','" + tamp_name3 + "')";
                }

                try
                {
                    con.Open();
                    SqlCommand cmdi = new SqlCommand();
                    cmdi = con.CreateCommand();
                    cmdi.CommandText = sql;
                    cmdi.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    hit = 0;
                    name = "";
                    tamp_name1 = "";
                    tamp_name2 = "";
                    tamp_name3 = "";
                    con.Close();
                    
                }
    
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            string sql = "";
            string[] nama = { };

            SqlConnection con = new SqlConnection();
            konek kelas1 = new konek();
            con.ConnectionString = kelas1.koneksi;

            sql = "select * from Table_1 order by name3";
            try
            { 
                openFileDialog1.ShowDialog();
                textBox1.Text = openFileDialog1.FileName.ToString();

                File.WriteAllText(textBox1.Text,"");

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    int i = 1;
                    while (dr.Read())
                    {
                        string name1 = dr.GetString(0);
                        string name2 = dr.GetString(1);
                        string name3 = dr.GetString(3);

                        nama[i] = name1+ name2 + name3;
                        i = i + 1;
                    }
                    // Append new lines of text to the file
                    //File.AppendAllLines(Path.Combine(docPath, "WriteFile.txt"), lines);
                    File.AppendAllLines(textBox1.Text, nama);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
